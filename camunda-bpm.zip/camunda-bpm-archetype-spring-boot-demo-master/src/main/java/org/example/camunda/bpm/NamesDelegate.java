package org.example.camunda.bpm;

import java.util.Collections;
import java.util.logging.Logger;
import org.json.JSONObject;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.fasterxml.jackson.core.JsonProcessingException;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

@Component
public class NamesDelegate implements JavaDelegate {
    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }

    private final Logger LOGGER = Logger.getLogger(NamesDelegate.class.getName());

    @Override
    public void execute(DelegateExecution execution) throws Exception {
        Message message = (Message) (execution.getVariable("name"));
        Long id = message.getId();
        makePostRequest(id,message.getMessage());
       

    }

    public static void makePostRequest(Long id,String message) {
        RestTemplate restTemplate = new RestTemplate();
        
        // Define the URL of the REST API endpoint
        String url = "https://rickandmortyapi.com/api/character/" + id;

        // Set the Content-Type header to application/json
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));

        // Create an HttpEntity with headers (no body needed for GET)
        HttpEntity<String> entity = new HttpEntity<>(headers);

        // Make the GET request and receive the response
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);

        // Assuming 'response' contains the JSON response as a String
        String responseBody = response.getBody();

        // Parse the response body into a JSONObject
        JSONObject jsonObject = new JSONObject(responseBody);

        // Extract the name value
        String name = jsonObject.getString("name");
        // Optionally, print the response body
        System.out.println(message+" " + name);
    }
}