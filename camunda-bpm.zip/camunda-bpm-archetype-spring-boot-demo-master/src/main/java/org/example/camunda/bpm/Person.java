package org.example.camunda.bpm;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Person implements Serializable {
    private static final long serialVersionUID = 1L;
    @JsonProperty("id")
	int id;
    @JsonProperty("message") // Adjust as necessary to match JSON
    String message;
    
    // Default no-argument constructor
    public Person() {
    }

    Person(int id, String message) {
      this.id = id;
      this.message = message;
    }

    public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getmessage() {
		return message;
	}

	public void setmessage(String message) {
		this.message = message;
	}

	@Override
    public String toString() {
      return "Person{id=" + id + ", message='" + message + '\'' + '}';
    }

}
