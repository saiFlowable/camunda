package org.example.camunda.bpm;

import java.util.List;

import org.camunda.bpm.engine.RuntimeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class AppRunner implements CommandLineRunner {
	
@Autowired	
public RuntimeService runtimeService;

	@Override
	public void run(String... args) throws Exception {
		
		runtimeService.startProcessInstanceByKey("messageProcess");
	}

}
