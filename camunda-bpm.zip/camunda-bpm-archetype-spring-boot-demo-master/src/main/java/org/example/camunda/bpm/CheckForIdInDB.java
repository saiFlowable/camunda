package org.example.camunda.bpm;

import java.util.logging.Logger;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class CheckForIdInDB implements JavaDelegate {
	private final Logger LOGGER = Logger.getLogger(NamesDelegate.class.getName());
	@Autowired
	UserService userService;

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		// TODO Auto-generated method stub
		Message message = (Message) (execution.getVariable("name"));
		Long id = message.getId();
		Name name = userService.getNameById(id);
		if (name == null || name.getName() == null || name.getName().isEmpty()) {
			execution.setVariable("nameFound", "true");
			LOGGER.info("NAME is NOT FOUND looking for new Name");
			execution.setVariableLocal("nameFound", "false");
		} else {
			LOGGER.info(message.getMessage()+","+name.getName());
		}
	}

}
