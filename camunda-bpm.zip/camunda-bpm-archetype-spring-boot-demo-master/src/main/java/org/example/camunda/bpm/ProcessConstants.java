package org.example.camunda.bpm;

public class ProcessConstants {

  public static final String PROCESS_DEFINITION_KEY = "camunda-process-application"; // BPMN Process ID

}
