package org.example.camunda.bpm;

import java.util.logging.Logger;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.json.JSONObject;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.fasterxml.jackson.core.JsonProcessingException;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

@Component
public class MessageNamesDelegate implements JavaDelegate {
    
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }


    @Override
    public void execute(DelegateExecution execution) throws Exception {
        Message message = (Message) (execution.getVariable("name"));
        makePostRequest(message);
      

    }

    public static void makePostRequest(Message message) {
        RestTemplate restTemplate = new RestTemplate();
        ObjectMapper objectMapper = new ObjectMapper();
        // Define the URL of the REST API endpoint
        String url = "https://echo.free.beeceptor.com";

        String requestBody = null;
        try {
            requestBody = objectMapper.writeValueAsString(message);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            return; // Exit the method if conversion fails
        }

        // Set the Content-Type header to application/json
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        // Create the HttpEntity containing the request body and headers
        HttpEntity<String> request = new HttpEntity<>(requestBody, headers);

        // Make the POST request and receive the response
        ResponseEntity<String> responseEntity = restTemplate.exchange(url, HttpMethod.POST, request, String.class);

        // Check the status code of the response
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            // If response is 200 OK, print a specific message
            System.out.println(message.getMessage()+" " + "OK");
        } else {
            // If response is not 200 OK, print a different message
            System.out.println(message.getMessage()+" "  + "Failed");
        }
        String responseBody = responseEntity.getBody();

        // Parse the response body into a JSONObject
        JSONObject jsonObject = new JSONObject(responseBody);

        // Extract the name value
        JSONObject parsedBody = jsonObject.getJSONObject("parsedBody");
        System.out.println("Response body: " + parsedBody);
        // Optionally, print the response body
        System.out.println(message.getMessage()+" " + parsedBody.getString("message"));
        // Optionally, print the response body
        
    }
}