package org.example.camunda.bpm;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.logging.Logger;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class DatabaseNamesDelegate implements JavaDelegate {


  @Autowired
  UserService userService;
  
  @Override
  public void execute(DelegateExecution execution) throws Exception {
	  List<Message> users = userService.getAllUsers();
    execution.setVariable("names", users);
   
    
    
    
  }

 
}