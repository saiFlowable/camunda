package org.example.camunda.bpm;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

	@Autowired
    private MessagesRepository userRepository;
	
	@Autowired
	private NamesRepository namesRepository;

    public Message createUser(Message user) {
        return userRepository.save(user);
    }

    public List<Message> getAllUsers() {
        return userRepository.findAll();
    }

    public Message getUserById(Long id) {
        return userRepository.findById(id).orElse(null);
    }

    public Message updateUser(Message updatedUser) {
        return userRepository.save(updatedUser);
    }

    public void deleteUser(Long id) {
        userRepository.deleteById(id);
    }
    
    public Name createNames(Name user) {
        return namesRepository.save(user);
    }
    public Name getNameById(Long id) {
        return namesRepository.findById(id).orElse(null);
    }


}
